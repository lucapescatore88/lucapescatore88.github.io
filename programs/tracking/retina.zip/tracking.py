import Tkinter as tk
from PIL import Image, ImageTk
import random
import numpy as np
import math
import FileDialog
import event_generator as evtgen
from planes_geometry import planes_geom as planes
import retina

class Tracking(object):

    def __init__(self, parent):

        parent.title('TRACKING')
        self.parent = parent
        self.plane_img = None
        self.evt_img = None
        self.retina_img = None
        
        self.initialize()

        self.geom = planes(
            nplanes = 20,    # Number of planes
            pl_dist = 3., # Plane to plane distance
            planes_inner_radius = 1, # cm
            planes_outer_radius = 30, # cm
            )
            
        self.evt_gen = evtgen.event_generator(
            geometry = self.geom,
            hit_eff = 1.,    # Hit efficiency. 1 for simplicity
            lumi_sigma = [0.1,0.1,5.], # Luminosity region gaussian with sigma = 5 cm around 0
            sigma = [0.1,0.1,0.,30.]
        )

    def generate(self) :

        self.evt_gen.generate_event(ntracks = int(self.nvts_scale.get()), nnoise = int(self.noise_scale.get()))
        self.evt_gen.draw_plane(self.evt_gen.tracks, self.evt_gen.noise, planes=[5])
        
        self.plimg = Image.open('plane5.png')
        self.plimg = self.plimg.resize((400,400), Image.ANTIALIAS)
        self.plane_img = ImageTk.PhotoImage(self.plimg)
        self.evimg = Image.open('event.png')
        self.evimg = self.evimg.resize((600,400), Image.ANTIALIAS)
        self.event_img = ImageTk.PhotoImage(self.evimg)
        
        self.draw_event()

    def draw_event(self) :

        self.clear()
        
        self.evwin = tk.Label(self.bottom_frame,image=self.event_img)
        self.evwin.image = self.event_img
        self.evwin.pack(side=tk.LEFT)
        self.plwin = tk.Label(self.bottom_frame,image=self.plane_img)
        self.plwin.image = self.plane_img
        self.plwin.pack(side=tk.RIGHT)

        if self.retina_img is not None :

            self.retina_window = tk.Toplevel()
            self.retina_window.title("Retina algorithm result")
            self.retwin = tk.Label(self.retina_window,image=self.retina_img)
            self.retwin.image = self.retina_img
            self.retwin.pack()



    def analyse(self):
        
        myretina = retina.retina(npoints = 100, nplanes = 20, pl_dist = 3., twoD=True)
        myretina.analyse_event(tracks=self.evt_gen.tracks,noise=self.evt_gen.noise)
        myretina.plot_grid("z0","alpha")
        
        self.retimg = Image.open('retina.png')
        self.retimg = self.retimg.resize((400,400), Image.ANTIALIAS)
        self.retina_img = ImageTk.PhotoImage(self.retimg)
    
        self.draw_event()
            
    def clear(self):
        
        if self.evwin  is not None : self.evwin.pack_forget()
        if self.plwin  is not None : self.plwin.pack_forget()
        if self.retwin is not None :
            self.retwin.pack_forget()
        if self.retina_window is not None :
            self.retina_window.destroy() 


    def initialize(self):
  
        self.evwin = None
        self.plwin = None
        self.retwin = None
        self.retina_window = None

        self.top_frame = tk.Frame(self.parent)
        self.top_frame.pack(side=tk.TOP)

        self.buttons_frame = tk.Frame(self.top_frame)
        self.buttons_frame.pack(side=tk.TOP)
        self.scales_frame = tk.Frame(self.top_frame)
        self.scales_frame.pack(side=tk.BOTTOM)

        # add restart button on top frame
        generate_button = tk.Button(self.buttons_frame, text='Generate Event', width=15, command=self.generate)
        generate_button.pack(side = tk.LEFT)
        clear_button = tk.Button(self.buttons_frame, text='Clear', width=15, command=self.clear)
        clear_button.pack(side = tk.RIGHT)
        analyse_button = tk.Button(self.buttons_frame, text='Analyse', width=15, command=self.analyse)
        analyse_button.pack(side = tk.RIGHT)
         
        self.nvts_scale = tk.Scale(self.scales_frame, from_=0, to=50, orient=tk.HORIZONTAL, label="# tracks", length=200)
        self.nvts_scale.pack(anchor=tk.E,side = tk.LEFT)
        self.noise_scale = tk.Scale(self.scales_frame, from_=0, to=100, orient=tk.HORIZONTAL, label="# noise per plane", length=200)
        self.noise_scale.pack(side = tk.RIGHT)

        self.bottom_frame=tk.Frame(self.parent,width=1000,height=400)
        self.bottom_frame.pack(side=tk.BOTTOM)


root = None
def ask_quit():
    #import tkMessageBox
    #if tkMessageBox.askokcancel("Quit", "You want to quit now?"):
    root.destroy()
    
if __name__ == '__main__':

    root = tk.Tk()  # Instantiate a root window
    window = Tracking(root)  # Instantiate a Game object
    root.protocol("WM_DELETE_WINDOW", ask_quit)
    root.mainloop()  # Enter the main event loop

