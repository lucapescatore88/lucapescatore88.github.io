import Tkinter as tk
import numpy as np
import random as rndm
from math import *
import time
from network import Network as net
import bdt
import os

class Board(object):

    def __init__(self, parent):

        self.plotsize = 500
        parent.title('POINTS')
        self.parent = parent
        
        self.sig_pts = []
        self.bkg_pts = []
        
        self.pts_size = 0.01
        self.scale = self.plotsize*0.9
        self.x_offset = 0.05
        self.y_offset = 0.05
        
        self.getting_sig = False
        self.getting_bkg = False
        self.ID_new_point = False
        
        self.initialize()

    ################### GRAPHICS AND GENERAL FUNCTIONS ###############################

    def point_in_canvas(self,x,y) :
    
        return (x >= 0)*(y >= 0)*(x <= 1)*(y <= 1)

    def get_trimmed_line(self,m,q) :
        pts = []
        
        if q is None :
            return self.scaled([[m, 0], [m,1]])
        
        ## Intersection with left border
        pts.append([0, q])
        
        ## Intersection with right border
        pts.append([1, m+q])
        
        if m != 0 :

            ## Intersection with lower border
            pts.append([-q/m,0])
            
            ## Intersection with upper border
            pts.append([(1-q)/m,1])
        
        #pts = list(set(pts))
        pts = [i for i in pts if self.point_in_canvas(i[0],i[1])]
        return self.scaled(pts)
        
    def callback(self,event) :
        point = ( event.x, event.y )
        scaled_point = self.scaled([point], reverse=True)[0]
        id = 0
        if self.ID_new_point == "BDT":
            id = self.bdt.BDTout(scaled_point)
        elif self.ID_new_point == "NN":
            id =  self.NN.NNout(scaled_point)[0][0] - 0.5
            print id
        elif self.getting_sig :
            id = 1

        
        if id < 0.1 :
            self.bkg_pts.append(scaled_point)
        else :
            self.sig_pts.append(scaled_point)
        
        self.draw_canvas()
        self.middle_frame.update_idletasks()
        self.bottom_frame.update_idletasks()
    
    def IDnewPoint(self) :
    
        self.ID_new_point = "BDT"
        self.my_lbl_txt.set("Identifying new points using BDTs")
    
    def IDnewPointNN(self) :
    
        self.ID_new_point = "NN"
        self.my_lbl_txt.set("Identifying new points using NNs")

    def add_bkg_point(self):
        self.ID_new_point = None
        self.getting_bkg = not self.getting_bkg
        self.getting_sig = not self.getting_bkg
        self.my_lbl_txt.set("Getting background points")
        
    def add_sig_point(self):
        self.ID_new_point = None
        self.getting_sig = not self.getting_sig
        self.getting_bkg = not self.getting_sig
        self.my_lbl_txt.set("Getting singal points")
        
    def scaled(self, points, reverse = False) :
        res = []
        if not reverse :
            for p in points :
                res.append( ( (p[0]+self.x_offset)*self.scale, (1.-p[1]+self.y_offset)*self.scale) )
        else :
            for p in points :
                res.append( ( p[0]/self.scale-self.x_offset, -(-1.+p[1]/self.scale-self.y_offset) ) )
        return res
    
    def dist(self,a,b) :
        return sqrt( (a[0]-b[0])*(a[0]-b[0]) + (a[1]-b[1])*(a[1]-b[1]) )
    
    def draw_points(self, highlight=[], pts = []):
        
        r = self.pts_size
        for p in self.bkg_pts :
            border = 0
            if p in highlight :
                border = 5
            self.canvas.create_oval((p[0]+r+self.x_offset)*self.scale, (1.-p[1]-r+self.y_offset)*self.scale,
            (p[0]-r+self.x_offset)*self.scale, (1.-p[1]+r+self.y_offset)*self.scale, fill = "blue", width = border)
            
        for p in self.sig_pts :
            border = 0
            if p in highlight :
                border = 5
            self.canvas.create_oval((p[0]+r+self.x_offset)*self.scale, (1.-p[1]-r+self.y_offset)*self.scale,
            (p[0]-r+self.x_offset)*self.scale, (1.-p[1]+r+self.y_offset)*self.scale, fill = "red", width = border)
        
        for p in pts :
            self.canvas.create_oval((p[0]+r+self.x_offset)*self.scale, (1.-p[1]-r+self.y_offset)*self.scale,
            (p[0]-r+self.x_offset)*self.scale, (1.-p[1]+r+self.y_offset)*self.scale, fill = "black")
    
    def draw_lines(self, lines = [], highlight=[] ):
        for l in lines :
            p1, p2 = self.get_trimmed_line(l[0], l[1])
            self.canvas.create_line(p1[0],p1[1],p2[0],p2[1])
    
    def draw_canvas(self, extra_pts = [], lines = [], HL = []) :
        self.canvas.delete("all")
        self.draw_points(highlight = HL, pts = extra_pts)
        self.draw_lines(lines)
        self.middle_frame.update_idletasks()
    
    def reset(self) :
        self.bkg_pts = []
        self.sig_pts = []
        self.draw_canvas()
    
    def load_pts(self) :
    
        print "Loading data/sig_pts.txt and data/bkg_pts.txt"
        if not os.path.exists("data") :
            print "ATTENTION! 'data' folder does not exists"
            return
        
        fbkg = open("data/bkg_pts.txt","r")
        fsig = open("data/sig_pts.txt","r")
        bkgpts = fbkg.readlines()
        sigpts = fsig.readlines()
        self.reset()
        for p in bkgpts:
            comps = p.split()
            curpt = []
            for c in comps :
                curpt.append(float(c))
            self.bkg_pts.append( (curpt) )
        for p in sigpts:
            comps = p.split()
            curpt = []
            for c in comps :
                curpt.append(float(c))
            self.sig_pts.append( tuple(curpt) )
        self.draw_canvas()

    def save_pts(self) :
    
        if not os.path.exists("data") :
            os.makedirs("data")
            
        fbkg = open("data/bkg_pts.txt","w")
        fsig = open("data/sig_pts.txt","w")
        
        for p in self.bkg_pts :
            fbkg.write(str(p[0])+"  "+str(p[1])+"\n")
        for p in self.sig_pts :
            fsig.write(str(p[0])+"  "+str(p[1])+"\n")
        
        fbkg.close()
        fsig.close()
    
    def initialize(self):
        
        self.top_frame = tk.Frame(self.parent)
        self.top_frame.pack(side=tk.TOP)

        BDT_button = tk.Button(self.top_frame, text='BDT', width=10, command=self.BDT)
        BDT_button.pack(side = tk.RIGHT)
        NN_button = tk.Button(self.top_frame, text='NeuralNet', width=10, command=self.NeuralNet)
        NN_button.pack(side = tk.RIGHT)    

        self.mup_frame = tk.Frame(self.parent)
        self.mup_frame.pack(side=tk.TOP)
        save_button = tk.Button(self.mup_frame, text='Save', width=10, command=self.save_pts)
        save_button.pack(side = tk.LEFT)
        reset_button = tk.Button(self.mup_frame, text='Reset', width=10, command=self.reset)
        reset_button.pack(side = tk.LEFT)
        load_button = tk.Button(self.mup_frame, text='Load', width=10, command=self.load_pts)
        load_button.pack(side = tk.LEFT)
            
        self.mbt_frame = tk.Frame(self.parent)
        self.mbt_frame.pack(side=tk.BOTTOM)
        self.get_sig_button = tk.Button(self.mbt_frame, text='Get Sig. point', width=15, command=self.add_sig_point)
        self.get_sig_button.pack(side = tk.LEFT)
        self.get_bkg_button = tk.Button(self.mbt_frame, text='Get Bkg. point', width=15, command=self.add_bkg_point)
        self.get_bkg_button.pack(side = tk.RIGHT)

        self.mbt_frame2 = tk.Frame(self.parent)
        self.mbt_frame2.pack(side=tk.BOTTOM)
        self.ID_BDT_button = tk.Button(self.mbt_frame2, text='ID new pt (BDT)', width=15, command=self.IDnewPoint)
        self.ID_BDT_button.pack(side = tk.RIGHT)
        self.ID_NN_button = tk.Button(self.mbt_frame2, text='ID new pt (NN)', width=15, command=self.IDnewPointNN)
        self.ID_NN_button.pack(side = tk.RIGHT)

        self.middle_frame=tk.Frame(self.parent)
        self.middle_frame.pack()

        self.canvas = tk.Canvas(self.middle_frame,
        width=self.plotsize,
        height=self.plotsize)
        self.canvas.bind("<Button-1>", self.callback)
        self.canvas.pack()
        
        self.draw_points() 

        self.canvas.pack()
        
        self.bottom_frame=tk.Frame(self.parent)
        self.bottom_frame.pack(side=tk.BOTTOM)
        
        self.my_lbl_txt = tk.StringVar()
        self.my_lbl=tk.Label(self.bottom_frame, textvariable=self.my_lbl_txt)
        self.my_lbl.pack()
    
        self.load_pts()


################## NN   ###############################

    def convert_points(self, pts = []) :
        
        nvar = len(pts[0])
        res = []
        for x in pts :
            res.append(np.array(x).reshape((nvar,1)))
        return res

    def NeuralNet(self) :
        nvar = len(self.sig_pts[0])
        self.NN = net([nvar,nvar+1,1])
        
        bkg_tuple = [ ( x, np.array([[0.]]) ) for x in self.convert_points(self.bkg_pts) ]
        sig_tuple = [ ( x, np.array([[1.]]) ) for x in self.convert_points(self.sig_pts) ]
        data = sig_tuple
        data.extend(bkg_tuple)
        rndm.shuffle(data)
        test_data = data[:len(data)/5]
        train_data = data[len(data)/5+1:]

        #print test_data
        self.NN.SGD(train_data,200,20,0.1,test_data)
        
################ BDT #########################################

    def BDT(self) :
        
        self.bdt = bdt.BDT(self.sig_pts,self.bkg_pts)
        self.bdt.train()
        boundary = self.bdt.get_boundary()
        self.draw_canvas(extra_pts = boundary)
    
if __name__ == '__main__':
    
    root = tk.Tk()  # Instantiate a root window
    b = Board(root)  # Instantiate a Game object
    root.mainloop()  # Enter the main event loop

